# FinalProject
Final Project for the Sheffield Hallam Bcs Computer Science for Games degree

The project should already be compiled on bin/Debug folder. If not found or not working,
Enter build folder and run project.bat
Enter project folder and open VulkanEngine.sln with Visual Studio 2017
Press F5 to compile and run.

Camera controls:
  Right mouse click to take control. While pressing down right click,
  WASD to move,
  mouse movement to rotate.

